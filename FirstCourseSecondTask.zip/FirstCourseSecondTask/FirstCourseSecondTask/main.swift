//
//  main.swift
//  FirstCourseSecondTask
//
//  Copyright © 2017 E-Legion. All rights reserved.
//
import Foundation
import FirstCourseSecondTaskChecker


let checker = Checker()

//Задание 1
private func first(_ arrInt: [Int]) -> (Int, Int) {
    var evenCounter = 0
    arrInt.forEach() { number in
        if number % 2 == 0 {
            evenCounter += 1
        }
    }
    return (evenCounter, arrInt.count - evenCounter)
}

checker.checkFirstFunction(function: first)

//Задание 2
private func second(_ arrCircle:[Checker.Circle]) -> [Checker.Circle] {
    var buffer: [Checker.Circle]
    
    // Используем функцию compactMap, так надо возможен возврат nil, а такие элементы возвращать не надо
    buffer = arrCircle.compactMap() {
        var s = $0
       switch s.color {
        case .black:
            s.radius *= 2
        case .red:
            return nil
       case .green:
        s.color = .blue
       default: 
        return s
        
            }
        return s
    }
    
    //Финальная сортировка
    let white = buffer.filter() { $0.color == .white}
    let blue = buffer.filter() {$0.color == .blue}
    let without = buffer.filter() {$0.color != .blue && $0.color != .white}
    buffer = white + without + blue
    
    return buffer
   
}
checker.checkSecondFunction(function: second)

//Задание 3
func third(_ dictEmp: [Checker.EmployeeData]) -> [Checker.Employee] {
    
    var buffer = [Checker.Employee]()
    let keyFullName = "fullName"
    let keySalary = "salary"
    let keyCompany = "company"
    let checkDict = [keyFullName: "", keySalary: "", keyCompany :""]
    
    for value in dictEmp {
        if value.keys == checkDict.keys  {
           buffer.append(Checker.Employee(fullName: value[keyFullName]!, salary: value[keySalary]!, company: value[keyCompany]!))
        }
    }
    return buffer
}


checker.checkThirdFunction(function: third)

//Задание 4
func fourth(_ names: [String]) -> [String : [String]] {
    var dictNames = [String : [String]] ()
    for name in names {
        
        // Подсмотрел при разборе и разобрал guard заодно
        guard let a = name.first?.description else { continue }
        
        // Формируем первоначаный словарь
        if dictNames[a] != nil {
         dictNames[a]?.append(name)
        } else {
            dictNames[a] = [name]
        }
    }
    // Фильтруем словарь и удаляем лишние группы
    var final = [String : [String]] ()
    for (key, value) in dictNames {
        if value.count > 1 {
            let a = value.sorted(by: >)
            final[key] = a
        }
    }
    return final
}
checker.checkFourthFunction(function: fourth)

